package messaging;

import java.util.Collection;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;


@Transactional
public class MessagingTest extends m.abstractTestClass {

	@Autowired
	private MessagingRepository repo;

	@Before
	public void setup() {

	}

	@After
	public void post_precoess() {

	}

	@Test
	public void testFindAll() {
		Collection<Messaging> obj_list = (Collection<Messaging>) repo.findAll();
		Assert.assertNotNull("failure --expecting list not null", obj_list);
		Assert.assertEquals("failure -- expecting list size", 4, obj_list.size());

	}

	@Test
	public void testFindOne() {
		long id = 1;
		Messaging obj = repo.findOne(id);
		Assert.assertNotNull("failure --expecting list not null", obj);
		Assert.assertEquals("failer --expecting id 1", 1, obj.getId());

	}

	@Test
	public void testSave() {
		Messaging obj = new Messaging();
		obj.setUserName("houde");
		obj.setCreatedAt("13:26");
//		obj.setCreatedBy("houde");
		obj.setMessagingID("fourth_m");
		obj.setUpdatedAt("13:33");
//		obj.setUpdatedBy("houde");
		
		repo.save(obj);
		Assert.assertNotNull("failure --expecting list not null", obj);
		Assert.assertEquals("failer --expecting Messaging id to be fourth_m", "fourth_m", obj.getMessagingID());

	}
	
	@Test
	public void testDelete() {
		long id = 1;
		repo.delete(id);
		Assert.assertNull("failure --expecting Messaging 1 to be gone", repo.findOne(id));

	}
	
}
