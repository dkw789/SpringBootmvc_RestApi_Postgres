/*
 * Description : This is the controller of Spring MVC framework. The controller does the CRUD same as default CRUD provided by MongoRepository. But using controller allows more customizations and able to generate a interface as view.
 * */

package messaging;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.linkTo;

@Controller
@RequestMapping("/Messaging")
public class MessagingController {

    @Autowired
    private MessagingRepository repo;


    @RequestMapping(method=RequestMethod.GET)
    @ResponseBody
    public List<REST_Messaging> getAll() {
        List<Messaging> msg = (ArrayList<Messaging>) repo.findAll();
        List<REST_Messaging> rest_ms = new ArrayList<REST_Messaging>(msg.size());
        for(Messaging m : msg) {
            REST_Messaging rest_m = new REST_Messaging();
            rest_m.setMessagingID(m.getMessagingID());
            rest_m.setUserName(m.getUserName());
            rest_m.setUpdatedAt(m.getUpdatedAt());
            rest_m.setCreatedAt(m.getCreatedAt());
            rest_m.setLocation(m.getLocation());
            rest_m.setLatitude(m.getLatitude());
            rest_m.setTemperature(m.getTemperature());
            rest_m.add(linkTo(MessagingController.class).slash(m.getId()).withSelfRel());//Adding link to generate HATEOAS
            rest_ms.add(rest_m);
        }
        return rest_ms;
    }

    @RequestMapping(method=RequestMethod.GET, value="{id}")
    @ResponseBody
    public REST_Messaging goToIndividual(@PathVariable Long id) {
        Messaging m = repo.findOne(id);

        REST_Messaging rest_m = new REST_Messaging();
        rest_m.setMessagingID(m.getMessagingID());
        rest_m.setUserName(m.getUserName());
        rest_m.setUpdatedAt(m.getUpdatedAt());
        rest_m.setCreatedAt(m.getCreatedAt());
        rest_m.setLocation(m.getLocation());
        rest_m.setLatitude(m.getLatitude());
        rest_m.setLongitude(m.getLongitude());
        rest_m.setTemperature(m.getTemperature());
        rest_m.add(linkTo(MessagingController.class).slash(id).withSelfRel());
        return rest_m;
    }

    @RequestMapping(method=RequestMethod.POST)
    @ResponseBody
    public Messaging create(@RequestBody Messaging m) {
        return repo.save(m);
    }

    @RequestMapping(method=RequestMethod.DELETE, value="{id}")
    public void delete(@PathVariable Long id) {
        repo.delete(id);
    }

    @RequestMapping(method=RequestMethod.PUT, value="{id}")
    public Messaging update(@PathVariable Long id, @RequestBody Messaging m) {
        Messaging update = repo.findOne(id);
        update.setMessagingID(m.getMessagingID());
        update.setUserName(m.getUserName());
        update.setCreatedAt(m.getCreatedAt());
        update.setUpdatedAt(m.getUpdatedAt());
        update.setLocation(m.getLocation());
        update.setLatitude(m.getLatitude());
        update.setLongitude(m.getLongitude());
        update.setTemperature(m.getTemperature());
        return repo.save(update);
    }

    @RequestMapping(value="/greeting", method=RequestMethod.GET)
    public String greetingForm(Model model) {
        model.addAttribute("greeting", new Messaging());
        return "greeting";
    }



    @RequestMapping(value="/greeting", method=RequestMethod.POST)
    public String greetingSubmit(@ModelAttribute Messaging greeting, Model model) {
        repo.save(greeting);
        model.addAttribute("greeting", greeting);
        //return "redirect:/Messaging/greeting/result";
        return "result";
    }


//    @RequestMapping("/messagesAjaxRequest")
//    public @ResponseBody List<Messaging> messagesAjaxRequest(@ModelAttribute("MessagingForm") Messaging MessagingForm, ModelMap model) {
//
//        MessagingBO.prepareMessagingList(MessagingForm,model);
//
//        return MessagingForm.getMessagingList();
//    }
//    @RequestMapping(value="/allText{id}",  produces = "html/plain;charset=UTF-8")
//    @ResponseBody
//    public String allText(@PathVariable("id") int id, @ModelAttribute("cart") Cart cart,Model model)
//    {
//        Messaging m = m.getUserName(id);
//        if (product != null) {
//            CartLine line = new CartLine();
//            line.setProduct(product);
//            line.setQuantity(1);
//            productService.updateProduct(product);
//        }
//        return "<div>output</div>";
//    }
}
    


