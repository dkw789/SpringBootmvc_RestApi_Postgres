package messaging;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
@Repository
interface MessagingRepository extends CrudRepository<Messaging, Long>{

}

