//var today = new Date();
//document.getElementById('time').innerHTML=today;